Stables essentials archive

Generated: 2026-05-09

This archive is the compact public survival bundle for the Stables BCP onion resilience page.

Start here:
1. Verify SHA256SUMS.txt.
2. Read MANIFEST.json.
3. Use knowledge/llms.txt for the public Stables knowledge base.
4. Use downloads/Stables_v00.00.00.00.03.mds.zip as the approved showcase MiniDapp package if the sibling onion download is unavailable.
5. Check notices/ for current BCP continuity status.

Sensitive credentials, vault material, and private operational secrets are intentionally excluded.
