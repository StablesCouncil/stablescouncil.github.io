Stables essentials archive

Generated: 2026-10-25

This archive is the compact public survival bundle for the Stables BCP onion resilience page.

Start here:
1. Verify SHA256SUMS.txt.
2. Read MANIFEST.json.
3. Use knowledge/llms.txt for the public Stables knowledge base.
4. Use Stables_v0.0.14.046.apk as the one Android app. It runs its own Minima node, or uses Minima Core on your phone.
5. Check notices/ for current BCP continuity status.

Desktop app coming.

The Stables card is an experiment. It needs a thorough security review by independent experts before it can be used in production.

Sensitive credentials, vault material, and private operational secrets are intentionally excluded.
