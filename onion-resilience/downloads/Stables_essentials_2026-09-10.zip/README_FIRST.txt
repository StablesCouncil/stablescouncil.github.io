Stables essentials archive

Generated: 2026-09-10

This archive is the compact public survival bundle for the Stables BCP onion resilience page.

Start here:
1. Verify SHA256SUMS.txt.
2. Read MANIFEST.json.
3. Use knowledge/llms.txt for the public Stables knowledge base.
4. Open webapp/index.html for the browser demo when clearnet is unavailable.
5. Use downloads/Stables_v0.0.11.88.mds.zip as the published demo MiniDapp package for Minima hub install.
6. Use downloads/Stables_v0.0.11.88.apk as the standalone Android app with embedded Minima node.
7. Check notices/ for current BCP continuity status.

Sensitive credentials, vault material, and private operational secrets are intentionally excluded.
